# CER-Bench final-deliverable manuscript

Entry point: `cerbench_final.tex`.

Title: **Relevance Labels and Source Identity Can Change Scientific Retrieval Conclusions: A CER-Bench Audit**.

This is the requested complete final-deliverable revision, not submission clearance, acceptance assurance, or a validated corrected-corpus benchmark. It replaces a benchmark-winner narrative with a joint source-identity and relevance-label audit. It contains the abstract, main argument, methods and results, limitations, reproducibility and ethics/AI-use statements, references, and technical appendices. No historical manuscript, PDF, archive, corpus, or source implementation was changed by this writing phase.

## Files and evidence

- `cerbench_final.tex`: complete anonymous ICLR-format source.
- `refs.bib`: unchanged copy of the existing submission bibliography; the manuscript cites 14 entries, with unused entries retained rather than rewritten. BibTeX prints the cited subset.
- `iclr2027_conference.sty`, `iclr2027_conference.bst`, `natbib.sty`, `fancyhdr.sty`: unchanged copies from `paper/iclr2027_submission/`.
- `figures/qrel_disclosure.pdf`: unchanged vector experiment figure. SHA-256: `155ef70e796a739f58f9963a706f1c42ea12a78a125f7861daf1e0803b4bff09`.
- `CLAIMS_TO_ARTIFACTS.md`: evidence ledger and limits on interpretation.
- `verify_static.py`: local, provider-free checks for citation keys, cross-references, environments, immutable copies, selected source counts, and prohibited manuscript placeholders/private paths.
- `static_checks.json`: written by a successful static-check invocation; it is not a compilation or scientific-validation report.

## Build and review

From this directory, use an available TeX environment:

```sh
tectonic cerbench_final.tex
```

Alternatively run `pdflatex`, `bibtex`, and two further `pdflatex` passes. Tectonic may need cached packages or network access to its bundle. No compilation was delegated to this writing phase; the lead owns compilation and PDF inspection. The source uses the existing official style without margin, font-size, spacing, page-height, or header overrides. It retains the style's anonymous submission mode, rather than claiming acceptance with a final-copy header. The target is approximately 7–9 main-text pages; actual pagination, figure legibility, table widths, and final PDF title/abstract correspondence require the lead's compile and review. No PDF is claimed until that step succeeds.

Run static checks from the analysis root with an interpreter containing the standard library:

```sh
python paper/iclr2027_final/verify_static.py
```

## Empirical boundary

Usable provider credentials remain unavailable and **no new model experiments have run**. The new empirical computations are authoritative metadata comparison, conservative local full-text restoration, historical-token Monte Carlo disclosure, and actual unscored local BM25 checks. The 56 native adapter plans are dry plans; its 24 local checks are not 24 live LLM trials. Structural and selective metric definitions are tested software, not biomedical scores.

Human validation was explicitly waived and not performed. The corrected 4,936-document/10,313-chunk dataset has no fresh source partition, newly generated benchmark tasks, human relevance labels, or corrected-corpus leaderboard. Historical tasks/qrels must not be silently reused. The 238-task post hoc repair (94/49/95) is already exposed and is not a fresh held-out benchmark. Source ownership is not semantic fidelity, clinical validity, or redistribution approval.

The native-adapter evidence retains a real unfiltered cross-suite failure: `tests/test_verified_bm25.py::test_actual_smoke_provenance` expected an earlier script hash (110 passed, 1 failed). Its later filtered suite reports 113 passed, 1 deselected. The manuscript states this rather than claiming all current tests pass. This writing phase runs only its static checks, not those empirical suites.

## Remaining lead action

Compile and visually inspect the manuscript; check main-text pagination and the three-panel vector figure at print size; confirm title and abstract in the output PDF; resolve TeX diagnostics without style manipulation. This is a document-verification step, not a request to invent results, run credential-dependent models, or treat waived human review as completed.
