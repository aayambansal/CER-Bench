# CER-Bench — ICLR 2027 LaTeX source

This directory contains the anonymous initial-submission version of the CER-Bench paper in the official ICLR 2027 format.

## Build

Run the following commands from this directory:

```sh
pdflatex -interaction=nonstopmode -halt-on-error -file-line-error cerbench_iclr2027.tex
bibtex cerbench_iclr2027
pdflatex -interaction=nonstopmode -halt-on-error -file-line-error cerbench_iclr2027.tex
pdflatex -interaction=nonstopmode -halt-on-error -file-line-error cerbench_iclr2027.tex
pdflatex -interaction=nonstopmode -halt-on-error -file-line-error cerbench_iclr2027.tex
```

The output is `cerbench_iclr2027.pdf`. The main text ends on page 9; the required AI-use statement, ethics and reproducibility statements, references, and appendices follow.

The `\iclrfinalcopy` command remains commented out, as required for double-blind review.

## Official template provenance

The style files were downloaded on 2026-08-20 from the official ICLR 2027 author-guidelines link:

<https://media.iclr.cc/Conferences/ICLR2027/iclr-2027-style-files.zip>

Archive SHA-256:

```text
0d940dfa9398ae99a18f24a85a8a683f367204b6af6d17d2899e60a67102529e
```
